# Snakes and ladders game

[![forthebadge](http://forthebadge.com/images/badges/made-with-c-plus-plus.svg)](http://forthebadge.com)
[![forthebadge](http://forthebadge.com/images/badges/built-with-love.svg)](http://forthebadge.com)

This is a snake and ladder game source code that is implemented with c++ programming language and has the following features.

## Features

- Bomb placement
- Two player game
- Ability to save the game

## Usage

```
git clone https://github.com/effati78/snake-and-ladder.git
```
Or download the project and run it

## ⭐️⭐️⭐️

To support me please star this project from the bar above.

